import boto3
import json
import os
import urllib3
import base64
from decimal import Decimal

# Initialize AWS Clients
s3 = boto3.client('s3')
bedrock = boto3.client(service_name='bedrock-runtime', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb')

# Configuration
TABLE_NAME = "FusionInvoicesTable"
WORKATO_WEBHOOK_URL = "https://webhooks.workato.com/webhooks/rest/a2b0ea68-5acb-4ed5-8817-980d5f4d487b/lambdatigger"

table = dynamodb.Table(TABLE_NAME)
http = urllib3.PoolManager()

def format_numbers(obj):
    """Recursively converts floats to Decimals for DynamoDB compatibility."""
    if isinstance(obj, list):
        return [format_numbers(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: format_numbers(v) for k, v in obj.items()}
    elif isinstance(obj, float):
        return Decimal(str(obj))
    return obj

def lambda_handler(event, context):
    try:
        # 1. Get S3 Event Details
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        
        # 2. Download File from S3
        file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
        file_content = file_obj['Body'].read()
        
        # Encode file to Base64 for Workato/Oracle
        base64_file = base64.b64encode(file_content).decode('utf-8')
        
        file_ext = file_key.split('.')[-1].lower()
        doc_format = 'pdf' if file_ext == 'pdf' else 'png'

        # 3. Targeted Prompt for Nova AI
        prompt = """
        [Role]: High-accuracy Financial Data Extractor.
        [Task]: Convert the attached invoice into a valid JSON object for Oracle Fusion.
        [Instructions]:
        - Extract 'InvoiceNumber', 'InvoiceCurrency', 'InvoiceAmount', 'InvoiceDate', 'Supplier', 'SupplierSite', and 'Description'.
        - Set 'BusinessUnit' to 'US1 Business Unit'.
        - Set 'InvoiceType' to 'Standard'.
        - Map items into 'invoiceLines' array. Each line MUST have: LineNumber, LineType (Item), LineAmount, and Description.
        - Return ONLY raw JSON. Do not include markdown or explanations.

        [JSON Schema]:
        {
          "InvoiceNumber": "string",
          "InvoiceCurrency": "string",
          "InvoiceAmount": number,
          "InvoiceType": "Standard",
          "InvoiceDate": "YYYY-MM-DD",
          "BusinessUnit": "US1 Business Unit",
          "Supplier": "string",
          "SupplierSite": "string",
          "Description": "string",
          "invoiceLines": [
            {
              "LineNumber": integer,
              "LineType": "Item",
              "LineAmount": number,
              "Description": "string"
            }
          ]
        }
        """

        # 4. Invoke Amazon Nova Lite
        response = bedrock.converse(
            modelId="amazon.nova-lite-v1:0",
            messages=[{
                "role": "user",
                "content": [
                    { "document": { "name": "Invoice", "format": doc_format, "source": { "bytes": file_content } } },
                    { "text": prompt }
                ]
            }],
            inferenceConfig={"temperature": 0}
        )
        
        # 5. Process and Clean AI Response
        raw_text = response['output']['message']['content'][0]['text'].strip()
        if "```" in raw_text:
            raw_text = raw_text.split("```json")[-1].split("```")[0].strip()
        
        invoice_data = json.loads(raw_text)

        # 6. Enrichment for DynamoDB & Workato
        invoice_data['S3_Location'] = f"s3://{bucket_name}/{file_key}"
        invoice_data['ProcessingStatus'] = 'Dynamo-Inserted'
        
        # Add Attachment Data for Oracle Fusion
        invoice_data['attachment'] = {
            "FileName": file_key.split('/')[-1],
            "FileContents": base64_file,
            "Category": "To Supplier",
            "ContentType": f"application/{doc_format}",
            "Title": f"Invoice {invoice_data.get('InvoiceNumber')}"
        }

        sanitized_data = format_numbers(invoice_data)

        # 7. Store in DynamoDB
        table.put_item(Item=sanitized_data)
        print(f"Stored Invoice {invoice_data.get('InvoiceNumber')} in DynamoDB.")

        # 8. Trigger Workato Webhook
        # FIX: Wrap the data in a "payload" key to match the Workato Schema
        # This prevents the "empty string" issue in your recipe
        wrapped_data = {
            "payload": invoice_data
        }

        hook_resp = http.request(
            'POST',
            WORKATO_WEBHOOK_URL,
            body=json.dumps(wrapped_data),
            headers={'Content-Type': 'application/json'}
        )
        
        print(f"Workato Response Status: {hook_resp.status}")

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Processed successfully', 'invoice': invoice_data.get('InvoiceNumber')})
        }

    except Exception as e:
        print(f"Critical Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }