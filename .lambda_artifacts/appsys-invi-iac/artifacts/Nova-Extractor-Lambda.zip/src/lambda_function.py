"""
Lambda 2: Invoice Extractor + DynamoDB Insert + Workato Trigger (FINAL + AUDIT) - CORRECTED
------------------------------------------------------------------------------------------
Fixes in this version:
✅ DocumentHash now computed from real file bytes (not derived from S3 key)
✅ Bedrock converse document bytes sent as base64 string (more reliable)
✅ Duplicate check is now schema-safe:
   - Uses GSI query if INVOICE_GSI_NAME is set
   - Else scan fallback (ENABLE_SCAN_FALLBACK=true) for demo environments
✅ Audit emit remains best-effort and will not break pipeline
✅ Better error handling/logging for Nova JSON parsing and Workato calls

Env vars:
- TABLE_NAME (default FusionInvoicesTable)
- WORKATO_WEBHOOK_URL
- WORKATO_API_TOKEN (optional)
- MODEL_ID (default amazon.nova-lite-v1:0)
- ENABLE_IDEMPOTENCY (default true)
- AUDIT_SQS_URL (required for audit)
- INVOICE_GSI_NAME (optional: e.g., InvoiceNumber-index)
- ENABLE_SCAN_FALLBACK (optional: true/false, default true)
- APP_NAME (optional)
- ENV (optional)
"""

import boto3
import json
import os
import urllib3
import base64
import uuid
import hashlib
from decimal import Decimal
from datetime import datetime, timezone
from boto3.dynamodb.conditions import Key, Attr


# -----------------------------
# AWS Clients
# -----------------------------
s3 = boto3.client("s3")
bedrock = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION", "us-east-1"))
dynamodb = boto3.resource("dynamodb")
http = urllib3.PoolManager(
    timeout=urllib3.Timeout(connect=20.0, read=60.0),
    retries=urllib3.Retry(2, backoff_factor=0.5),
)
sqs = boto3.client("sqs")


# -----------------------------
# Configuration
# -----------------------------
TABLE_NAME = os.getenv("TABLE_NAME", "FusionInvoicesTable")
WORKATO_WEBHOOK_URL = os.getenv(
    "WORKATO_WEBHOOK_URL",
    "https://webhooks.workato.com/webhooks/rest/a2b0ea68-5acb-4ed5-8817-980d5f4d487b/lambdatigger"
)
WORKATO_API_TOKEN = os.getenv("WORKATO_API_TOKEN", "")

MODEL_ID = os.getenv("MODEL_ID", "amazon.nova-lite-v1:0")
ENABLE_IDEMPOTENCY = os.getenv("ENABLE_IDEMPOTENCY", "true").lower() == "true"

# Audit configuration
AUDIT_SQS_URL = os.getenv("AUDIT_SQS_URL", "")
APP_NAME = os.getenv("APP_NAME", "AppSys-inVi")
ENV = os.getenv("ENV", "dev")

# Duplicate detection config
INVOICE_GSI_NAME = os.getenv("INVOICE_GSI_NAME", "")  # e.g., "InvoiceNumber-index"
ENABLE_SCAN_FALLBACK = os.getenv("ENABLE_SCAN_FALLBACK", "true").lower() == "true"

table = dynamodb.Table(TABLE_NAME)


# -----------------------------
# Helpers
# -----------------------------
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def format_numbers(obj):
    """Recursively converts floats to Decimals for DynamoDB compatibility."""
    if isinstance(obj, list):
        return [format_numbers(i) for i in obj]
    if isinstance(obj, dict):
        return {k: format_numbers(v) for k, v in obj.items()}
    if isinstance(obj, float):
        return Decimal(str(obj))
    return obj


def clean_nova_json(raw_text: str) -> str:
    """Strips markdown code fences and tries to isolate JSON."""
    txt = (raw_text or "").strip()

    if "```" in txt:
        txt = txt.replace("```json", "```")
        parts = txt.split("```")
        if len(parts) >= 3:
            txt = parts[1].strip()
        else:
            txt = txt.replace("```", "").strip()

    first_brace = txt.find("{")
    last_brace = txt.rfind("}")
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        txt = txt[first_brace:last_brace + 1].strip()

    return txt


def doc_format_from_filename(file_name: str) -> str:
    ext = (file_name.split(".")[-1] if "." in file_name else "").lower()
    if ext in ("jpg", "jpeg"):
        return "jpeg"
    if ext in ("tif", "tiff"):
        return "tiff"
    if ext in ("png", "pdf"):
        return ext
    return "pdf"


# -----------------------------
# Audit Emit (Best-effort)
# -----------------------------
def emit_audit_event_best_effort(payload: dict):
    if not AUDIT_SQS_URL:
        print("AUDIT_SQS_URL not set. Skipping audit emit.")
        return

    payload.setdefault("schemaVersion", "1.0")
    payload.setdefault("eventId", str(uuid.uuid4()))
    payload.setdefault("emittedAt", now_iso())
    payload.setdefault("app", APP_NAME)
    payload.setdefault("env", ENV)

    try:
        sqs.send_message(
            QueueUrl=AUDIT_SQS_URL,
            MessageBody=json.dumps(payload, default=str)
        )
        print(f"[AUDIT] Emitted to SQS. eventId={payload.get('eventId')}")
    except Exception as e:
        print(f"[AUDIT] Failed to emit to SQS (ignored): {str(e)[:300]}")


def get_raw_email_pointers_from_s3_metadata(bucket_name: str, file_key: str) -> dict:
    """
    Reads S3 object metadata if present.
    Note: Lambda1 currently does NOT set raw_bucket/raw_key, so these may remain empty.
    """
    try:
        head = s3.head_object(Bucket=bucket_name, Key=file_key)
        meta = head.get("Metadata", {}) or {}
        return {
            "raw_bucket": meta.get("raw_bucket", ""),
            "raw_key": meta.get("raw_key", ""),
            "message_id": meta.get("message_id", ""),
            "sender": meta.get("sender", ""),
            "subject": meta.get("subject", ""),
        }
    except Exception as e:
        print(f"[AUDIT] head_object metadata read failed (ignored): {str(e)[:200]}")
        return {"raw_bucket": "", "raw_key": "", "message_id": "", "sender": "", "subject": ""}


# -----------------------------
# Duplicate Checks (Schema-safe)
# -----------------------------
def invoice_already_exists(inv_no: str) -> bool:
    """
    Best effort duplicate detection:
    1) If INVOICE_GSI_NAME provided -> Query GSI on InvoiceNumber
    2) Else fallback Scan (demo scale) if ENABLE_SCAN_FALLBACK=true
    """
    if not inv_no:
        return False

    inv_no = str(inv_no).strip()
    if not inv_no:
        return False

    # 1) GSI query path (recommended)
    if INVOICE_GSI_NAME:
        try:
            resp = table.query(
                IndexName=INVOICE_GSI_NAME,
                KeyConditionExpression=Key("InvoiceNumber").eq(inv_no),
                Limit=1
            )
            return resp.get("Count", 0) > 0
        except Exception as e:
            print(f"[IDEMPOTENCY] GSI query failed (ignored): {str(e)[:200]}")
            # fall through to scan if enabled

    # 2) Scan fallback (demo only)
    if ENABLE_SCAN_FALLBACK:
        try:
            resp = table.scan(
                FilterExpression=Attr("InvoiceNumber").eq(inv_no),
                Limit=1
            )
            return len(resp.get("Items", [])) > 0
        except Exception as e:
            print(f"[IDEMPOTENCY] Scan failed (ignored): {str(e)[:200]}")

    # If neither works, fail-open
    return False


# -----------------------------
# Main
# -----------------------------
def lambda_handler(event, context):
    try:
        record = event["Records"][0]
        bucket_name = record["s3"]["bucket"]["name"]
        file_key = record["s3"]["object"]["key"]
        file_name = file_key.split("/")[-1]

        # Read raw pointers if present
        raw_meta = get_raw_email_pointers_from_s3_metadata(bucket_name, file_key)

        # Download file
        file_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
        file_content = file_obj["Body"].read()

        # ✅ Correct hash: computed from bytes (not derived from key)
        document_hash = sha256_hex(file_content)

        # Base64 for Oracle Fusion attachment
        base64_file = base64.b64encode(file_content).decode("utf-8")

        # Document format
        doc_format = doc_format_from_filename(file_name)

        # Prompt
        prompt = """
[Role]: High-accuracy Financial Data Extractor.
[Task]: Convert the attached invoice into a valid JSON object for Oracle Fusion.
[Instructions]:
- Extract 'InvoiceNumber', 'InvoiceCurrency', 'InvoiceAmount', 'InvoiceDate', 'Supplier', 'SupplierSite', and 'Description'.
- Set 'BusinessUnit' to 'US1 Business Unit'.
- Set 'InvoiceType' to 'Standard'.
- Map items into 'invoiceLines' array. Each line MUST have: LineNumber, LineType (Item), LineAmount, and Description.
- Return ONLY raw JSON. Do not include markdown or explanations.
"""

        # ✅ Correct Bedrock "bytes": pass base64 string
        doc_b64 = base64.b64encode(file_content).decode("utf-8")

        response = bedrock.converse(
            modelId=MODEL_ID,
            messages=[{
                "role": "user",
                "content": [
                    {"document": {"name": "Invoice", "format": doc_format, "source": {"bytes": doc_b64}}},
                    {"text": prompt}
                ]
            }],
            inferenceConfig={"temperature": 0}
        )

        raw_text = response["output"]["message"]["content"][0]["text"]
        cleaned = clean_nova_json(raw_text)

        try:
            invoice_data = json.loads(cleaned)
        except Exception as je:
            raise Exception(f"Nova returned non-JSON. parse_error={str(je)[:160]} cleaned={cleaned[:300]}")

        inv_no = invoice_data.get("InvoiceNumber")

        # Idempotency check
        if ENABLE_IDEMPOTENCY and invoice_already_exists(inv_no):
            print(f"[IDEMPOTENT] Invoice {inv_no} already exists. Skipping DynamoDB + Workato.")

            emit_audit_event_best_effort({
                "Decision": "REJECTED",
                "RejectLayer": "LAYER2_INVOICE_TABLE",
                "RejectCode": "REJECTED_DUPLICATE_INVOICENUMBER",
                "RejectReason": f"InvoiceNumber already exists in {TABLE_NAME}",
                "DetectedAt": now_iso(),
                "InvoiceNumber": inv_no,
                "Supplier": invoice_data.get("Supplier", ""),
                "SupplierSite": invoice_data.get("SupplierSite", ""),
                "InvoiceAmount": str(invoice_data.get("InvoiceAmount", "")),
                "InvoiceCurrency": invoice_data.get("InvoiceCurrency", ""),
                "DocumentHash": document_hash,
                "SourceFileName": file_name,
                "SilverS3Path": f"s3://{bucket_name}/{file_key}",
                "RawEmailS3Path": (
                    f"s3://{raw_meta['raw_bucket']}/{raw_meta['raw_key']}"
                    if raw_meta.get("raw_bucket") and raw_meta.get("raw_key")
                    else ""
                ),
                "RawBucket": raw_meta.get("raw_bucket", ""),
                "RawKey": raw_meta.get("raw_key", ""),
                "MessageID": raw_meta.get("message_id", ""),
                "Sender": raw_meta.get("sender", ""),
                "Subject": raw_meta.get("subject", ""),
            })

            return {"statusCode": 200, "body": json.dumps({"message": "Skipped (duplicate InvoiceNumber)", "invoice": inv_no})}

        # Enrichment fields
        invoice_data["S3_Location"] = f"s3://{bucket_name}/{file_key}"
        invoice_data["ProcessingStatus"] = "Dynamo-Inserted"
        invoice_data["ProcessedAt"] = now_iso()
        invoice_data["SourceFileName"] = file_name
        invoice_data["DocumentHash"] = document_hash

        # Attachment object for Fusion/Workato
        invoice_data["attachment"] = {
            "FileName": file_name,
            "FileContents": base64_file,
            "Category": "To Supplier",
            "ContentType": "application/pdf" if doc_format == "pdf" else f"image/{doc_format}",
            "Title": f"Invoice {invoice_data.get('InvoiceNumber')}"
        }

        # DynamoDB write
        sanitized = format_numbers(invoice_data)
        table.put_item(Item=sanitized)
        print(f"[DDB] Stored Invoice {inv_no} in DynamoDB. Hash={document_hash}")

        # Workato trigger
        wrapped_data = {"payload": invoice_data}

        headers = {"Content-Type": "application/json"}
        if WORKATO_API_TOKEN:
            headers["API-Token"] = WORKATO_API_TOKEN

        hook_resp = http.request(
            "POST",
            WORKATO_WEBHOOK_URL,
            body=json.dumps(wrapped_data),
            headers=headers
        )

        print(f"[Workato] Response Status: {hook_resp.status}")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Processed successfully",
                "invoice": inv_no,
                "workato_status": hook_resp.status
            })
        }

    except Exception as e:
        print(f"Critical Error: {str(e)}")

        emit_audit_event_best_effort({
            "Decision": "FAILED",
            "RejectLayer": "LAMBDA2_RUNTIME",
            "RejectCode": "FAILED_EXCEPTION",
            "RejectReason": str(e)[:500],
            "DetectedAt": now_iso(),
        })

        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}