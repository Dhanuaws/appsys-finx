"""
Lambda 1: AP Invoice Audit & Classifier (FULL FINAL VERSION)
------------------------------------------------------------
Designed for your current setup:

S3 (raw email objects)  --->  Lambda 1  --->  S3 (email-attachment/<hash>/...)
                                         --->  DynamoDB RawEmailMetaData
S3 (email-attachment/ prefix trigger) ---> Lambda 2 (extract + DDB + Workato)

✅ Works with your DynamoDB schema:
   PK = MessageID
   SK = ReceivedDate

✅ Features
- Always logs email metadata first (Status=PROCESSING)
- Processes MULTIPLE attachments per email
- Saves only non-duplicate, valid invoices
- Duplicate detection is TRUE dedupe using SHA-256 folder prefix
- Clean S3 naming convention:
    email-attachment/<sha256>/<senderTag>_<dateTag>_<originalFilename>
- Standard reject codes:
    REJECTED_DUPLICATE, REJECTED_NOTANINVOICE, etc.
- Partial success supported:
    - Some saved + some rejected => Status=PARTIAL_COMPLETED
    - All rejected => Status=SKIPPED_ALL_REJECTED
- Fixes DynamoDB reserved keyword issue for "Status" using ExpressionAttributeNames
"""

import json
import re
import os
import email
import base64
import logging
import hashlib
from email import policy
from datetime import datetime, timezone
from urllib.parse import unquote_plus

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError


# -----------------------------
# CONFIG
# -----------------------------
TARGET_PREFIX = os.getenv("TARGET_PREFIX", "email-attachment/")
DYNAMODB_TABLE = os.getenv("DYNAMODB_TABLE", "RawEmailMetaData")

ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".tiff"}
MAX_ATTACHMENT_BYTES = int(os.getenv("MAX_ATTACHMENT_BYTES", str(4 * 1024 * 1024)))
TENANT_ID = os.getenv("TENANT_ID", "tenant-appsys-dev")

NOVA_MODEL_ID = os.getenv("NOVA_MODEL_ID", "amazon.nova-lite-v1:0")
BEDROCK_READ_TIMEOUT = int(os.getenv("BEDROCK_READ_TIMEOUT", "60"))


# -----------------------------
# STANDARD REJECT CODES
# -----------------------------
REJECT_DUPLICATE   = "REJECTED_DUPLICATE"
REJECT_NOT_INVOICE = "REJECTED_NOTANINVOICE"
REJECT_RISKY       = "REJECTED_RISKY"  # placeholder for future fraud checks
REJECT_EXTENSION   = "REJECTED_INVALID_EXTENSION"
REJECT_TOO_LARGE   = "REJECTED_FILE_TOO_LARGE"
REJECT_EMPTY       = "REJECTED_EMPTY_FILE"
REJECT_AI_ERROR    = "REJECTED_AI_ERROR"
REJECT_S3_ERROR    = "REJECTED_S3_ERROR"
REJECT_EMAIL_PARSE = "REJECTED_EMAIL_PARSE"


# -----------------------------
# AWS CLIENTS
# -----------------------------
s3 = boto3.client("s3")
bedrock = boto3.client("bedrock-runtime", config=Config(read_timeout=BEDROCK_READ_TIMEOUT))
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(DYNAMODB_TABLE)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("invoice-audit")


# -----------------------------
# HELPERS
# -----------------------------
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_filename(name: str) -> str:
    name = os.path.basename(name or "attachment")
    name = re.sub(r"[^\w\d.\-]", "_", name)
    return name[:180]


def sender_domain(sender: str) -> str:
    """
    Extract domain from From header.
    Examples:
      "Name <user@vendor.com>" -> vendor.com
      "user@vendor.com" -> vendor.com
    Returns "unknown" if not found.
    """
    if not sender:
        return "unknown"
    m = re.search(r"@([A-Za-z0-9\.\-]+\.[A-Za-z]{2,})", sender)
    return m.group(1).lower() if m else "unknown"


def sender_tag(sender: str) -> str:
    # Turn domain into safe token: vendor.com -> vendor_com
    d = sender_domain(sender).replace(".", "_")
    return safe_filename(d) or "unknown"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_doc_format(ext: str) -> str:
    """Nova document format normalization."""
    x = (ext or "").lower().lstrip(".")
    if x == "jpg":
        return "jpeg"
    if x == "tif":
        return "tiff"
    return x or "pdf"


def classify_with_nova(attachment_bytes: bytes, ext: str) -> dict:
    """
    Returns:
      {
        "ok": bool,
        "is_invoice": bool,
        "type": "Invoice"|"Credit Memo"|"Other",
        "error": optional str
      }
    """
    encoded = base64.b64encode(attachment_bytes).decode("utf-8")
    doc_format = normalize_doc_format(ext)

    prompt = (
        "Decide if the attached document is an official Invoice or Credit Memo.\n"
        "Return ONLY strict JSON in this schema:\n"
        "{\n"
        "  \"is_invoice\": boolean,\n"
        "  \"type\": \"Invoice\" | \"Credit Memo\" | \"Other\"\n"
        "}\n"
        "No markdown. No explanation.\n"
    )

    body = json.dumps({
        "inferenceConfig": {"maxTokens": 120, "temperature": 0.0},
        "messages": [{
            "role": "user",
            "content": [
                {"text": prompt},
                {"document": {"format": doc_format, "name": "doc", "source": {"bytes": encoded}}}
            ]
        }]
    })

    try:
        response = bedrock.invoke_model(modelId=NOVA_MODEL_ID, body=body)
        res_text = json.loads(response["body"].read())["output"]["message"]["content"][0]["text"]
        cleaned = re.sub(r"```json|```", "", (res_text or "")).strip()
        parsed = json.loads(cleaned)

        is_invoice = bool(parsed.get("is_invoice", False))
        doc_type = str(parsed.get("type", "Other"))[:40]

        return {"ok": True, "is_invoice": is_invoice, "type": doc_type}
    except Exception as e:
        return {"ok": False, "is_invoice": False, "type": "Error", "error": str(e)[:400]}


# -----------------------------
# CORE PROCESSOR
# -----------------------------
def process_record(record: dict):
    bucket = record["s3"]["bucket"]["name"]
    key = unquote_plus(record["s3"]["object"]["key"])

    # Prevent loops if the same bucket notification includes the attachment prefix
    if key.startswith(TARGET_PREFIX):
        logger.info(f"Skipping object already under {TARGET_PREFIX}: s3://{bucket}/{key}")
        return

    received_date = now_iso()

    # Try reading + parsing raw email
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        msg = email.message_from_bytes(obj["Body"].read(), policy=policy.default)
    except Exception as e:
        # Even parsing failures should be logged
        fallback_id = key
        table.put_item(Item={
            "MessageID": fallback_id,
            "ReceivedDate": received_date,
            "Sender": "Unknown",
            "Subject": "Unknown",
            "S3RawPath": f"s3://{bucket}/{key}",
            "Status": "FAILED_EMAIL_PARSE",
            "LastUpdated": now_iso(),
            "Attachments": [],
            "Error": f"{REJECT_EMAIL_PARSE}: {str(e)[:300]}"
        })
        logger.exception(f"Failed to parse email: s3://{bucket}/{key}")
        return

    message_id = msg.get("Message-ID", key)
    sender = msg.get("From", "Unknown")
    subject = msg.get("Subject", "No Subject")

    # 1) INITIAL LOG
    table.put_item(Item={
        "MessageID": message_id,
        "ReceivedDate": received_date,
        "tenantId": TENANT_ID,
        "Sender": sender,
        "Subject": subject,
        "S3RawPath": f"s3://{bucket}/{key}",
        "Status": "PROCESSING",
        "LastUpdated": now_iso()
    })

    audit = []

    # Walk through MIME parts to find attachments
    for part in msg.walk():
        filename = part.get_filename()
        if not filename:
            continue

        filename = safe_filename(filename)
        ext = os.path.splitext(filename)[1].lower()

        entry = {
            "file": filename,
            "status": None,          # SAVED or REJECTED
            "rejectCode": None,      # REJECTED_DUPLICATE, etc
            "rejectReason": None,
            "s3": None,
            "sha256": None,
            "sizeBytes": None,
            "docType": None
        }

        # Gate 1: Extension allowlist
        if ext not in ALLOWED_EXTENSIONS:
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_EXTENSION
            entry["rejectReason"] = f"Unsupported extension: {ext}"
            audit.append(entry)
            continue

        data = part.get_payload(decode=True)
        if not data:
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_EMPTY
            entry["rejectReason"] = "Attachment is empty or decode failed"
            audit.append(entry)
            continue

        entry["sizeBytes"] = len(data)

        # Gate 2: Size limit
        if len(data) > MAX_ATTACHMENT_BYTES:
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_TOO_LARGE
            entry["rejectReason"] = f"File exceeds limit {MAX_ATTACHMENT_BYTES} bytes"
            audit.append(entry)
            continue

        # Hash for true dedupe
        file_hash = sha256_hex(data)
        entry["sha256"] = file_hash

        # Build dedupe-safe + readable S3 key:
        # email-attachment/<hash>/<senderTag>_<dateTag>_<originalFilename>
        date_tag = datetime.now().strftime("%d%b%y")
        s_tag = sender_tag(sender)
        hash_prefix = f"{TARGET_PREFIX}{file_hash}/"
        dest = f"{hash_prefix}{s_tag}_{date_tag}_{filename}"

        # Duplicate check using hash folder existence (MaxKeys=1)
        try:
            resp = s3.list_objects_v2(Bucket=bucket, Prefix=hash_prefix, MaxKeys=1)
            if "Contents" in resp and len(resp["Contents"]) > 0:
                entry["status"] = "REJECTED"
                entry["rejectCode"] = REJECT_DUPLICATE
                entry["rejectReason"] = "Duplicate detected using SHA256 hash"
                audit.append(entry)
                continue
        except Exception as e:
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_S3_ERROR
            entry["rejectReason"] = f"S3 list_objects_v2 error: {str(e)[:160]}"
            audit.append(entry)
            continue

        # AI classification
        ai = classify_with_nova(data, ext)

        if not ai.get("ok"):
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_AI_ERROR
            entry["rejectReason"] = f"Nova invocation failed: {ai.get('error','unknown')}"
            audit.append(entry)
            continue

        entry["docType"] = ai.get("type", "Other")

        if ai.get("is_invoice") is True:
            # Save to S3
            try:
                s3.put_object(
                    Bucket=bucket,
                    Key=dest,
                    Body=data,
                    Metadata={
                        "MessageID": str(message_id)[:200],
                        "Hash": file_hash,
                        "Type": ai.get("type", "Invoice")[:40],
                        "OriginalFileName": filename[:180],
                        "Sender": s_tag[:80]
                    }
                )
                entry["status"] = "SAVED"
                entry["s3"] = dest
            except Exception as e:
                entry["status"] = "REJECTED"
                entry["rejectCode"] = REJECT_S3_ERROR
                entry["rejectReason"] = f"S3 put_object failed: {str(e)[:160]}"
        else:
            entry["status"] = "REJECTED"
            entry["rejectCode"] = REJECT_NOT_INVOICE
            entry["rejectReason"] = f"Nova classified as {ai.get('type','Other')}"

        audit.append(entry)

    # 2) FINAL STATUS (compute from audit)
    saved_count = sum(1 for a in audit if a.get("status") == "SAVED")
    rejected_count = sum(1 for a in audit if a.get("status") == "REJECTED")

    if len(audit) == 0:
        final_status = "SKIPPED_NO_ATTACHMENTS"
    elif saved_count == 0:
        final_status = "SKIPPED_ALL_REJECTED"
    elif saved_count > 0 and rejected_count > 0:
        final_status = "PARTIAL_COMPLETED"
    else:
        final_status = "COMPLETED"

    # 3) FINAL UPDATE (Status is reserved keyword => alias)
    table.update_item(
        Key={"MessageID": message_id, "ReceivedDate": received_date},
        UpdateExpression="SET Attachments=:a, #st=:s, ProcessedAt=:p, LastUpdated=:lu",
        ExpressionAttributeNames={"#st": "Status"},
        ExpressionAttributeValues={
            ":a": audit,
            ":s": final_status,
            ":p": now_iso(),
            ":lu": now_iso()
        }
    )


def lambda_handler(event, context):
    records = event.get("Records", [])
    for record in records:
        try:
            process_record(record)
        except Exception as e:
            logger.exception(f"Critical Failure: {str(e)}")
    return {"statusCode": 200, "body": json.dumps({"message": "OK"})}